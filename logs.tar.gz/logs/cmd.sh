#!/bin/bash
rm -rf *.log

for dir in N*;
do
    rm -rf $dir/*Tdata.avg
    rm -rf $dir/threads.final
    # rm -rf $dir/*.gz
    # rm -rf $dir/data*
    for file in $dir/*.log;
		do
			echo -n $file >> $file-Tdata.avg
			echo -n "|" >> $file-Tdata.avg
    		tail -n 1 $file >> $file-Tdata.avg
    		# mv $dir/*.avg .
    		cat $file-Tdata.avg >> $dir/threads.final
    	done
    # cat $dir/threads.final | cut -d':' -f2 | sed ':a;N;$!ba;s/\n/,/g' >> $dir/threads.final
    cat $dir/threads.final | cut -d':' -f2 >> $dir/threads.final

done

# rm -rf final.txt
# for file in *.avg;
# do
# 	# echo -n $file >> final.txt;
# 	cat $file >> Threads.txt
# done
# tr '\n' ' ' < input_filename